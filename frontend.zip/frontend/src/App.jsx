import { Routes, Route } from "react-router-dom";
import CouncilList from "./components/CouncilList";
import CouncilDetails from "./components/CouncilDetails";
import CouncilClubs from "./components/CouncilClubs";
import Navbar from "./components/Navbar/Navbar";
import FestDetails from "./components/FestDetails";
import CellList from "./components/CellList"
import CellDetails from "./components/CellDetails"
import FestList from "./components/FestList";
import EventDetails from "./components/EventDetails";
import ClubDetails from "./components/ClubDetails";
import {AllEvents} from "./components/AllEvents";
import EventCreationForm from "./components/EventCreate";


function App() {
  return (
    <div className="bg-black min-h-screen text-white">
      <Navbar />
      <Routes>
        <Route path="/events" element={<AllEvents />} />
        <Route path="/councils" element={<CouncilList />} />
        <Route path="/cells" element={<CellList />} />
        <Route path="/fests" element={<FestList />} />
        <Route path="/cells/:id" element={<CellDetails />} />
        <Route path="/councils/:id" element={<CouncilDetails />} />
        <Route path="/fests/:tag" element={<FestDetails />} />
        <Route path="/councils/clubs/:tag" element={<CouncilClubs />} />
        <Route path="/councils/clubs/:tag/:id" element={<ClubDetails />} />
        <Route path="/events/:id" element={<EventDetails />} />
        <Route path="/admin/createEvent" element={<EventCreationForm />} />
      </Routes>
    </div>
  );
}

export default App;
