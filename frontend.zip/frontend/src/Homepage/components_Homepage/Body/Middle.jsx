import React from "react";

function Middle() {
    return (
        <div className="homepage_body-middle-0">
            <p className="homepage_body-middle">
                Eventrix is the online platform to manage our campus events, nothing new!
            </p>
        </div>
    );
}
export default Middle;