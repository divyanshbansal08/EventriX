import React from "react";

function Header() {
    return (
        <div className="homepage_body-header">
            <h1 className="homepage_body-header-h1">
                EventriX, just so you can get out of the matrix!
            </h1>
        </div>
    );
}
export default Header;