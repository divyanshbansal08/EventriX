const cardcontent = [
    {
        key: 1,
        title: "Name*",
        value: "Your Name"
    },
    {
        key: 2,
        title: "Email / Roll Number*",
        value: "Your email (abc@iitk.ac.in)"
    }
];

export default cardcontent;