const cardcontent_login = [
    {
        key: 1,
        title: "Email / Roll Number*",
        value: "Your email (abc@iitk.ac.in)"
    }
];

export default cardcontent_login;