import React from "react";

function Footer_login() {
    return (<div className="login_footer">
        <footer className="signup_text-size-small">
            Copyright © 2025
        </footer>
    </div>);
}
export default Footer_login;