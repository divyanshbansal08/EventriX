import React from "react";
import Logo from "./Logo";
import Footer from "./Footer";
import Body_changepassword from "./Body_changepassword";

function Change_password() {
    return (
        <div className="main_wrapper_signin-0">
            <div className="main_wrapper_signin-1">
                <div className="main_wrapper_signin-2">
                    <Logo />
                    <Body_changepassword />
                    <Footer />
                </div>
            </div>
        </div>
    );
};

export default Change_password;