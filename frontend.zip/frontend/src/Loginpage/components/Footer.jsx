import React from "react";

function Footer() {
    return (<div className="signup_signup_footer">
        <footer className="signup_text-size-small">
            Copyright © 2025
        </footer>
    </div>);
}
export default Footer;