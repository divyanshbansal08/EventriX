const councilClubsData = [
    {
      tag: "mnc",
      clubs: [
        {
            id: 1,
            name: "Amine Society",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {

              }
            ],
        }, 
        {
            id: 2,
            name: "Book Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "",
            coordinators: [
              {

              }
            ],
        },
        {
          id: 3,
          name: "Dance Club",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        }, 
        {
          id: 4,
          name: "Debating Society",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        },
        {
          id: 5,
          name: "Design and Animation Club",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        },
        {
          id: 6,
          name: "Dramatics Club",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        },
        {
          id: 7,
          name: "English Literary Society",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        }, 
        {
          id: 8,
          name: "Fine Arts Club",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        },
        {
          id: 9,
          name: "Film Club",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        }, 
        {
          id: 10,
          name: "Hindi Sahitya Sabha",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        },
        {
          id: 11,
          name: "Humour House",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        }, 
        {
          id: 12,
          name: "Music Club",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        },
        {
          id: 13,
          name: "Photography Club",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        }, 
        {
          id: 14,
          name: "Quiz Club",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        },
        {
          id: 15,
          name: "Noor IITK",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        },
        {
          id: 16,
          name: "Meraki",
          shortDesc: "We Dance Here",
          longDesc: "",
          img: "../../mnclogo.jpg",
          coordinators: [
            {

            }
          ],
        },
        
      ],
     
      
    },
    {
        tag: "snt",
        clubs: [
          {
              id: 1,
              name: "Aeromodelling Club",
              shortDesc: "We Dance Here",
              longDesc: "",
              img: "../../mnclogo.jpg",
              coordinators: [
                {
  
                }
              ],
          }, 
          {
              id: 2,
              name: "Astronomy Club",
              shortDesc: "We Dance Here",
              longDesc: "",
              img: "",
              coordinators: [
                {
  
                }
              ],
          },
          {
            id: 3,
            name: "Brain and Cognitive Science Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }, 
          {
            id: 4,
            name: "Electronics Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 5,
            name: "Finance and Analytics Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 6,
            name: "Game Development Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 7,
            name: "Programming Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }, 
          {
            id: 8,
            name: "Robotics Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }, 
          {
            id: 9,
            name: "DesCon Society",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 10,
            name: "Science Coffee House",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 11,
            name: "IITK Consulting Group",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 12,
            name: "Team AUV",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 13,
            name: "Team ERA",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 14,
            name: "Team IITK Motorsports",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }, 
          {
            id: 15,
            name: "Team RASET",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 16,
            name: "Team Humanoid",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 17,
            name: "Team Vision",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }
        ]
    },
    {
        tag: "gns",
        clubs: [
          {
              id: 1,
              name: "Adventure Club",
              shortDesc: "We Dance Here",
              longDesc: "",
              img: "../../mnclogo.jpg",
              coordinators: [
                {
  
                }
              ],
          }, 
          {
              id: 2,
              name: "Card and Board Games",
              shortDesc: "We Dance Here",
              longDesc: "",
              img: "",
              coordinators: [
                {
  
                }
              ],
          },
          {
            id: 3,
            name: "Chess Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }, 
          {
            id: 4,
            name: "Shooting Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 5,
            name: "Skating Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 6,
            name: "Taekwondo Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 7,
            name: "Boxing Hobbie Group",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }, 
          {
            id: 8,
            name: "Ultimate Frisbee Society",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }, 
          {
            id: 9,
            name: "Archery Society",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 10,
            name: "Aquatics",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 11,
            name: "Athletics",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 12,
            name: "Badminton",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 13,
            name: "Basketball",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 14,
            name: "Cricket",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }, 
          {
            id: 15,
            name: "Football",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 16,
            name: "Hockey",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 17,
            name: "Lawn Tennis",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 18,
            name: "Squash",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 19,
            name: "Table Tennis",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 20,
            name: "Volleyball",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 21,
            name: "Weight Lifting",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }, 
          {
            id: 22,
            name: "E-Sports Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }
        ]
    },
    {
        tag: "anc",
        clubs: [
          {
              id: 1,
              name: "Academics Wing",
              shortDesc: "We Dance Here",
              longDesc: "",
              img: "../../mnclogo.jpg",
              coordinators: [
                {
  
                }
              ],
          }, 
          {
              id: 2,
              name: "Career Development Wing",
              shortDesc: "We Dance Here",
              longDesc: "",
              img: "",
              coordinators: [
                {
  
                }
              ],
          },
          {
            id: 3,
            name: "Research Wing",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }, 
          {
            id: 4,
            name: "International Relations Wing",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 5,
            name: "Product Club",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 6,
            name: "Web Wing",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
          {
            id: 7,
            name: "Media and Publicity Wing",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          }, 
          {
            id: 8,
            name: "Outreach and Finance Wing",
            shortDesc: "We Dance Here",
            longDesc: "",
            img: "../../mnclogo.jpg",
            coordinators: [
              {
  
              }
            ],
          },
        ]
    },
  ];

export default councilClubsData;