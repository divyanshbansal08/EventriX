import React from "react";

function Header_councilspage() {
    return (
        <div className="councilspage_header-0">
            <div className="councilspage_header-1">
                <div className="councilspage_header-2 councilspage_header-21">
                    <h2 className="councilspage_header-3-h2">
                        Councils
                    </h2>
                </div>
            </div>
        </div>
    );
};

export default Header_councilspage;