import React from "react";

function Tags_council(props) {
    return (
        <div className="councilspage_council_tag">
            <div>#{props.val}</div>
        </div>
    );
};

export default Tags_council;