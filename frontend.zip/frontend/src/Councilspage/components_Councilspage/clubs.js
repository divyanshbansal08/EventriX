const clubs = [
    { id: 1, title: "Media and Culture", date: "March 30, 2025", description: "A coding competition to test your skills.", image: "../mnclogo.jpg" },
    { id: 2, title: "Science and Technology", date: "April 10, 2025", description: "Enjoy live music performances and bands.", image: "../sntlogo.jpg" },
    { id: 3, title: "Games and Sports", date: "April 20, 2025", description: "Join experts discussing latest tech trends.", image: "../gnslogo.jpg" },
    { id: 4, title: "Acads and Career", date: "April 20, 2025", description: "Join experts discussing latest tech trends.", image: "../anclogo.png" }
  ];
  
  export default clubs;
  