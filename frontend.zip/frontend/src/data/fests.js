const fests=[
    {
        id: 1,
        tag: "antaragni",
        name: "Antaragni",
        shortDesc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas dapibus tincidunt vehicula. Nullam luctus orci vel lacus porttitor condimentum. Quisque tortor sapien, gravida eget faucibus ut, ultrices vel est.",
        longDesc: 
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas dapibus tincidunt vehicula. Nullam luctus orci vel lacus porttitor condimentum. Quisque tortor sapien, gravida eget faucibus ut, ultrices vel est. Nullam non tempus orci, non scelerisque ipsum. Aliquam ac vestibulum ligula, nec maximus enim. Donec consequat placerat augue eu luctus. Proin blandit lorem sed justo tristique scelerisque.Aenean placerat ipsum ac venenatis ullamcorper. Sed pulvinar aliquet sapien, eu viverra nisi semper nec. Aliquam nec ultrices justo. Nulla facilisi. Ut vulputate lorem augue, eget feugiat turpis dapibus eu. Nunc dignissim velit id orci tristique ultricies. Donec maximus imperdiet eros vel vehicula. Fusce a pulvinar velit. Suspendisse laoreet leo at tellus rutrum, in accumsan ante pulvinar. Ut vulputate neque quis enim blandit blandit. Nam efficitur lectus leo, eget congue sem dapibus ut. Integer gravida vitae nunc at porttitor.",
        img: "../../antaragnilogo.jpeg",
        vid: "https://www.youtube.com/watch?v=EDfXjGl1kys",
        coordinators: [
          {

          }
        ],   
    },
    {
        id: 2,
        tag: "udghosh",
        name: "Udghosh",
        shortDesc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas dapibus tincidunt vehicula. Nullam luctus orci vel lacus porttitor condimentum. Quisque tortor sapien, gravida eget faucibus ut, ultrices vel est.",
        longDesc: 
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas dapibus tincidunt vehicula. Nullam luctus orci vel lacus porttitor condimentum. Quisque tortor sapien, gravida eget faucibus ut, ultrices vel est. Nullam non tempus orci, non scelerisque ipsum. Aliquam ac vestibulum ligula, nec maximus enim. Donec consequat placerat augue eu luctus. Proin blandit lorem sed justo tristique scelerisque.Aenean placerat ipsum ac venenatis ullamcorper. Sed pulvinar aliquet sapien, eu viverra nisi semper nec. Aliquam nec ultrices justo. Nulla facilisi. Ut vulputate lorem augue, eget feugiat turpis dapibus eu. Nunc dignissim velit id orci tristique ultricies. Donec maximus imperdiet eros vel vehicula. Fusce a pulvinar velit. Suspendisse laoreet leo at tellus rutrum, in accumsan ante pulvinar. Ut vulputate neque quis enim blandit blandit. Nam efficitur lectus leo, eget congue sem dapibus ut. Integer gravida vitae nunc at porttitor.",
        img: "../../udghoshlogo.png",
        vid: "https://www.youtube.com/watch?v=EDfXjGl1kys",
        coordinators: [
          {

          }
        ],  
    },
    {
        id: 3,
        tag: "techkriti",
        name: "Techkriti",
        shortDesc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas dapibus tincidunt vehicula. Nullam luctus orci vel lacus porttitor condimentum. Quisque tortor sapien, gravida eget faucibus ut, ultrices vel est.",
        longDesc: 
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas dapibus tincidunt vehicula. Nullam luctus orci vel lacus porttitor condimentum. Quisque tortor sapien, gravida eget faucibus ut, ultrices vel est. Nullam non tempus orci, non scelerisque ipsum. Aliquam ac vestibulum ligula, nec maximus enim. Donec consequat placerat augue eu luctus. Proin blandit lorem sed justo tristique scelerisque.Aenean placerat ipsum ac venenatis ullamcorper. Sed pulvinar aliquet sapien, eu viverra nisi semper nec. Aliquam nec ultrices justo. Nulla facilisi. Ut vulputate lorem augue, eget feugiat turpis dapibus eu. Nunc dignissim velit id orci tristique ultricies. Donec maximus imperdiet eros vel vehicula. Fusce a pulvinar velit. Suspendisse laoreet leo at tellus rutrum, in accumsan ante pulvinar. Ut vulputate neque quis enim blandit blandit. Nam efficitur lectus leo, eget congue sem dapibus ut. Integer gravida vitae nunc at porttitor.",
        img: "../../techkritilogo.jpg",
        vid: "https://www.youtube.com/watch?v=EDfXjGl1kys",
        coordinators: [
          {

          }
        ],  
    }
]

export default fests;