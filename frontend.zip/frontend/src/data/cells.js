const cells = [
  {
    id: 68,
    name: "Community Welfare Cell",
    shortDesc: " Lorem ipsum dolor sit, amet consectetur adipisicing elit. Tempora nobis m",
    longDesc: "",
    img: "../../default.jpeg",
    coordinators: [
      {

      }
    ],
  },
  {
    id: 69,
    name: "Election Commision",
    shortDesc: " Lorem ipsum dolor sit, amet consectetur adipisicing elit. Tempora nobis m",
    longDesc: "",
    img: "../../default.jpeg",
    coordinators: [
      {

      }
    ],
  },
  {
    id: 70,
    name: "Outreach Cell",
    shortDesc: " Lorem ipsum dolor sit, amet consectetur adipisicing elit. Tempora nobis m",
    longDesc: "",
    img: "../../default.jpeg",
    coordinators: [
      {

      }
    ],
  },
  {
    id: 71,
    name: "Entrepreneurship Cell",
    shortDesc: " Lorem ipsum dolor sit, amet consectetur adipisicing elit. Tempora nobis m",
    longDesc: "",
    img: "../../default.jpeg",
    coordinators: [
      {

      }
    ],
  },
  {
    id: 72,
    name: "Vox Populi",
    shortDesc: " Lorem ipsum dolor sit, amet consectetur adipisicing elit. Tempora nobis m",
    longDesc: "",
    img: "../../default.jpeg",
    coordinators: [
      {

      }
    ],
  },
];

  export default cells;